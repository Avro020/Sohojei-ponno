<?php
    include "dbconfig.php";
    session_start();
    if(isset($_SESSION["u_id"])){
        $uid = $_SESSION["u_id"];
        
        