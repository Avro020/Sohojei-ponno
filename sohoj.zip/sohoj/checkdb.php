<?php

$productid="";
$prname="";
$location="";
$price="";
$entry="";
$contact="";

if( isset($_POST['pid']) ){
	$productid=$_POST['pid'];
}

if( isset($_POST['prname']) ){
	$prname=$_POST['prname'];
}

if( isset($_POST['lname']) ){
	$location=$_POST['lname'];
}

if( isset($_POST['pprice']) ){
	$price=$_POST['pprice'];
}

if( isset($_POST['edate']) ){
	$entry=$_POST['edate'];
}

if( isset($_POST['pcon']) ){
	$contact=$_POST['pcon'];
}


try{
	$conn = new PDO("mysql:host=localhost;dbname=sohoj;","root","");
}
catch(PDOException $err){
	echo "<script>window.alert('db connection error');</script>";
	echo "<script>location.assign('index.php');</script>";
}

$sqlquery = "INSERT INTO product (product_id,Name,Location, price,entry_date,Contact_no)
VALUES ('$productid','$prname','$location','$price','$entry','$contact')";

$object=$conn->query($sqlquery);

if ($object->rowCount()==1) {
    echo "<script>location.assign('home.php');</script>";
}
else
{
    echo "<script>location.assign('index.php');</script>";
}

?>