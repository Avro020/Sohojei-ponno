<!DOCTYPE html>

<html>

	<head>
		<title>Product</title>
		
		<style>
		
		</style>
	</head>

	<body>
		<form method="post">
            product id: <input type="text" id="pid" name="pid" required>
			<br/>
            product name: <input type="text" id="prname" name="prname" required>
			<br/>
            Location: <input type="text" id="lname" name="lname" required>
			<br/>
            price: <input type="text" id="pprice" name="pprice" required>
			<br/>
            Entry Date: <input type="date" id="edate" name="edate" required>
			<br/>
            contact no: <input type="phoneCode" id="pcon" name="pcon" required>
			<br/>
            
			<input type="submit" value="Add" formaction="padd.php">
            <input type="submit" value="Update" formaction="pupdate.php">
            
		</form>
	</body>

</html>