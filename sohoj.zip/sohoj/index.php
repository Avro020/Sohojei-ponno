<!DOCTYPE html>
<html>
<head>
<style>

body {
  background-color: #D0ECE7;
}


input[type=text], select, textarea {
  width: 60%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 6px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #2471A3;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  float: left;
}

input[type=submit]:hover {
  background-color: #5499C7;
}

.container {
  border-radius: 6px;
  background-color: #D0ECE7;
  padding: 6px;
}

.col-25 {
  float: left;
  width: 10%;
  margin-top: 5px;
}

.col-75 {
  float: left;
  width: 65%;
  margin-top: 5px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>

<h2>Product Add & Update Form</h2>
  <form method="post">

<div class="container">
  <div class="row">
    <div class="col-25">
      <label for="pid">Product Id:</label>
    </div>
    <div class="col-75">
	  <input type="text" id="pid" name="pid" required="required" placeholder="Your Product Id..">
    </div>
  </div>
  
  <div class="row">
    <div class="col-25">
      <label for="prname">Product Name:</label>
    </div>
    <div class="col-75">
      <input type="text" id="prname" name="prname" required="required" placeholder="Your Product name..">
    </div>
	</div>
	
	<div class="row">
    <div class="col-25">
      <label for="lname">Location:</label>
    </div>
    <div class="col-75">
      <input type="text" id="lname" name="lname" required="required" placeholder="Your Location name..">
    </div>
	</div>
	
	
	<div class="row">
    <div class="col-25">
      <label for="pprice">Price:</label>
    </div>
    <div class="col-75">
      <input type="text" id="pprice" name="pprice" required="required" placeholder="Price..">
    </div></div>
	
	<div class="row">
    <div class="col-25">
      <label for="edate">Entry Date:</label>
    </div>
    <div class="col-75">
      <input type="date" id="edate" name="edate" required="required" placeholder="Date..">
    </div></div>
	
	<div class="row">
    <div class="col-25">
      <label for="pcon">Contact No:</label>
    </div>
    <div class="col-75">
      <input type="phoneCode" id="pcon" name="pcon" required="required" placeholder="+88019000000..">
    </div></div>
	

<div class="row">
   <input type="submit" value="Add" formaction="checkdb.php"> <nbsp>
   <input type="submit" value="Update" formaction="update.php">
  </div>
  
 
  </form>
</div>

</body>
</html>
