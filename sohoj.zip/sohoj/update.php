<?php

$productid="";
$prname="";
$location="";
$price="";
$entry="";
$contact="";

if( isset($_POST['pid']) ){
	$productid=$_POST['pid'];
}

if( isset($_POST['prname']) ){
	$prname=$_POST['prname'];
}

if( isset($_POST['lname']) ){
	$location=$_POST['lname'];
}

if( isset($_POST['pprice']) ){
	$price=$_POST['pprice'];
}

if( isset($_POST['edate']) ){
	$entry=$_POST['edate'];
}

if( isset($_POST['pcon']) ){
	$contact=$_POST['pcon'];
}


try{
	$conn = new PDO("mysql:host=localhost;dbname=sohoj;","root","");
}
catch(PDOException $err){
	echo "<script>window.alert('db connection error');</script>";
	echo "<script>location.assign('index.php');</script>";
}

$sqlquery = "UPDATE product
set name='$prname',
    Location='$location',
    price='$price',
    entry_date='$entry',
    Contact_no='$contact'
where product_id='$productid'";



if ($conn->query($sqlquery)==true) {
    echo "<script>location.assign('home2.php');</script>";
}
else
{
    echo "database failed";
}

?>